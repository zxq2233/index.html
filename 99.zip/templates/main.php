<?php
header("HTTP/1.1 302 Found");
header('Location: ./index.php?q=oKipp351c5ygsKrbsJfT36Q');
exit;
	?>