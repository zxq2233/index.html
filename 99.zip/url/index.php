<?php
$e=$_GET['url'];
header("Location:$e");